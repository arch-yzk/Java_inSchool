interface ExPlayer extends Player
{
    void slow();
}