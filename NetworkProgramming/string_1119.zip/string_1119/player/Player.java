//インタフェース　※自動的に抽象メソッド（abstract）となる
//Playerインタフェース
interface Player
{
    //再生
    void play();//public abstract void play()

    //停止
    void stop();
}